import jQuery from 'jquery/dist/jquery';

const $ = jQuery;
export { jQuery, $ };
